#include "Book.h"
#include <iostream>
#include <regex>
#include <ctime>

Book::Book()
    : title(""),
      author(""),
      isbn(""),
      isAvailable(true),
      dateAdded(std::chrono::system_clock::now()),
      isValidIsbn(true) {}

bool Book::validateIsbn(const std::string& isbn) const {
    // Accepts exactly 10 or 13 digits
    static const std::regex pattern(R"(^\d{10}$|^\d{13}$)");
    return std::regex_match(isbn, pattern);
}

void Book::setBookDetails(const std::string& title,
                          const std::string& author,
                          const std::string& isbn,
                          bool available) {
    this->title = title;
    this->author = author;
    this->isbn = isbn;
    this->isAvailable = available;
    this->dateAdded = std::chrono::system_clock::now();
    this->isValidIsbn = validateIsbn(isbn);
}

void Book::displayBookDetails() const {
    std::cout << "Title: " << title << "\n"
              << "Author: " << author << "\n"
              << "ISBN: " << isbn << "\n"
              << "Availability: " << (isAvailable ? "Available" : "Borrowed") << "\n";
    if (!isValidIsbn) {
        std::cout << "Error: Invalid ISBN!\n";
    }
    std::time_t tt = std::chrono::system_clock::to_time_t(dateAdded);
    std::string ds = std::ctime(&tt);
    if (!ds.empty() && ds.back() == '\n') ds.pop_back();
    std::cout << "DateAdded: " << ds << "\n";
}

bool Book::borrowBook() {
    if (isAvailable && isValidIsbn) {
        isAvailable = false;
        return true;
    }
    return false;
}

bool Book::returnBook() {
    if (!isAvailable) {
        isAvailable = true;
        return true;
    }
    return false;
}

std::string Book::getTitle() const { return title; }
std::string Book::getIsbn() const { return isbn; }
bool Book::isBookAvailable() const { return isAvailable; }
bool Book::isIsbnValid() const { return isValidIsbn; }
