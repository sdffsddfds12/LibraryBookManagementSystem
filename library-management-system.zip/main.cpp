#include <iostream>
#include <string>
#include "Book.h"

using namespace std;

void listAll(Book books[], int n) {
    cout << "\n=== Library Inventory (" << n << " books) ===\n";
    for (int i = 0; i < n; ++i) {
        cout << "\n-- Book #" << (i+1) << " --\n";
        books[i].displayBookDetails();
    }
    cout << "===============================\n";
}

int findByIsbn(Book books[], int n, const string& isbn) {
    for (int i = 0; i < n; ++i) {
        if (books[i].getIsbn() == isbn) return i;
    }
    return -1;
}

void bubbleSortByTitle(Book books[], int n) {
    for (int i = 0; i < n-1; ++i) {
        for (int j = 0; j < n-i-1; ++j) {
            if (books[j].getTitle() > books[j+1].getTitle()) {
                Book tmp = books[j];
                books[j] = books[j+1];
                books[j+1] = tmp;
            }
        }
    }
}

void sortingDemo() {
    cout << "\n=== Sorting Demo (3 arrays, then sorted ascending by Title) ===\n";

    Book asc[3];
    asc[0].setBookDetails("A Tale of Two Cities", "Charles Dickens", "1000000000");
    asc[1].setBookDetails("Brave New World", "Aldous Huxley", "1000000001");
    asc[2].setBookDetails("Crime and Punishment", "Fyodor Dostoevsky", "1000000002");

    Book desc[3];
    desc[0].setBookDetails("Zoo", "Author Z", "1000000003");
    desc[1].setBookDetails("Yellow", "Author Y", "1000000004");
    desc[2].setBookDetails("Alpha", "Author A", "1000000005");

    Book mixed[3];
    mixed[0].setBookDetails("Moby Dick", "Herman Melville", "1000000006");
    mixed[1].setBookDetails("The Catcher in the Rye", "J.D. Salinger", "1000000007");
    mixed[2].setBookDetails("A Clockwork Orange", "Anthony Burgess", "1000000008");

    auto show = [](const char* label, Book arr[3]) {
        cout << "\n-- " << label << " (before sort) --\n";
        for (int i = 0; i < 3; ++i) cout << arr[i].getTitle() << "\n";
        bubbleSortByTitle(arr, 3);
        cout << "-- " << label << " (after sort) --\n";
        for (int i = 0; i < 3; ++i) cout << arr[i].getTitle() << "\n";
    };

    show("Ascending", asc);
    show("Descending", desc);
    show("Mixed", mixed);
}

void displayMenu() {
    cout << "\n====== Library Menu ======\n"
            "1. List all books\n"
            "2. Borrow a book (by ISBN)\n"
            "3. Return a book (by ISBN)\n"
            "4. Sorting demo (3 arrays)\n"
            "0. Exit\n"
            "Enter choice: ";
}

int main() {
    const int N = 5;
    Book books[N];

    books[0].setBookDetails("The Great Gatsby", "F. Scott Fitzgerald", "1111111111");
    books[1].setBookDetails("1984", "George Orwell", "2222222222");
    books[2].setBookDetails("To Kill a Mockingbird", "Harper Lee", "3333333333");
    books[3].setBookDetails("Pride and Prejudice", "Jane Austen", "4444444444");
    books[4].setBookDetails("The Hobbit", "J.R.R. Tolkien", "5555555555");

    int choice = -1;
    string isbn;

    while (true) {
        displayMenu();
        if (!(cin >> choice)) break;
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear line

        if (choice == 0) {
            cout << "Exiting. Goodbye!\n";
            break;
        }

        switch (choice) {
            case 1: // list
                listAll(books, N);
                break;
            case 2: { // borrow
                cout << "Enter ISBN to borrow (0 to cancel): ";
                getline(cin, isbn);
                if (isbn == "0") break;
                int idx = findByIsbn(books, N, isbn);
                if (idx == -1) {
                    cout << "Book with ISBN " << isbn << " not found.\n";
                } else if (!books[idx].isIsbnValid()) {
                    cout << "Cannot borrow: invalid ISBN.\n";
                } else if (books[idx].borrowBook()) {
                    cout << "Borrowed successfully.\n";
                } else {
                    cout << "Already borrowed.\n";
                }
                break;
            }
            case 3: { // return
                cout << "Enter ISBN to return (0 to cancel): ";
                getline(cin, isbn);
                if (isbn == "0") break;
                int idx = findByIsbn(books, N, isbn);
                if (idx == -1) {
                    cout << "Book with ISBN " << isbn << " not found.\n";
                } else if (books[idx].returnBook()) {
                    cout << "Returned successfully.\n";
                } else {
                    cout << "This book was not borrowed.\n";
                }
                break;
            }
            case 4:
                sortingDemo();
                break;
            default:
                cout << "Invalid choice.\n";
        }
    }

    return 0;
}
