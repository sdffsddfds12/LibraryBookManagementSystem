#ifndef BOOK_H
#define BOOK_H

#include <string>
#include <chrono>

class Book {
private:
    std::string title;
    std::string author;
    std::string isbn;
    bool isAvailable;
    std::chrono::system_clock::time_point dateAdded;
    bool isValidIsbn;

    // Validate ISBN: numeric only, length 10 or 13
    bool validateIsbn(const std::string& isbn) const;

public:
    Book();
    void setBookDetails(const std::string& title,
                        const std::string& author,
                        const std::string& isbn,
                        bool available = true);
    void displayBookDetails() const;
    bool borrowBook();
    bool returnBook();

    // Getters
    std::string getTitle() const;
    std::string getIsbn() const;
    bool isBookAvailable() const;
    bool isIsbnValid() const;
};

#endif // BOOK_H
