# Library Management System (C++)

Simple console-based system for a community library. Manages book details, availability, borrowing/returning, and includes a sorting demo for testing.

## Features
- `Book` class with title, author, ISBN, availability, date added, and ISBN validation
- Borrow/return a book by ISBN (validation prevents borrowing invalid ISBNs)
- List all books
- Sorting demo: creates 3 small arrays (ascending, descending, mixed) then sorts by Title (Bubble Sort)

## Build & Run

### macOS / Linux
```bash
g++ -std=c++17 -o library_system main.cpp Book.cpp
./library_system
```

### Windows (MinGW)
```bash
g++ -std=c++17 -o library_system.exe main.cpp Book.cpp
library_system.exe
```

> Ensure all files (`main.cpp`, `Book.h`, `Book.cpp`) are in the same folder.

## Evidence of Program Output (What to capture)
- Successful **borrow**
- Error when borrowing a book that is **already borrowed**
- **Return** success
- Program **exit**
- Optional: Sorting demo before/after titles

## Evidence of Source Control (What to upload)
- Commit history showing `Initial implementation` and later changes
- Repository URL in your report
- Optional: screenshots of `git clone`, `git push`, `git pull`

## UML Class Diagram (Mermaid)

> GitHub renders Mermaid automatically in Markdown.

```mermaid
classDiagram
class Book {
  -string title
  -string author
  -string isbn
  -bool isAvailable
  -std::chrono::system_clock::time_point dateAdded
  -bool isValidIsbn
  +Book()
  +void setBookDetails(string title, string author, string isbn, bool available=true)
  +void displayBookDetails() const
  +bool borrowBook()
  +bool returnBook()
  +string getTitle() const
  +string getIsbn() const
  +bool isBookAvailable() const
  +bool isIsbnValid() const
  -bool validateIsbn(string isbn) const
}
```

## Suggested Repo Structure
```
.
├── Book.h
├── Book.cpp
├── main.cpp
├── README.md
└── .gitignore
```

## License
MIT (or your choice)
